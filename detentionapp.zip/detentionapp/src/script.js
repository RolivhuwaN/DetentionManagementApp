document.getElementById("detention-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = {
        teacherCode: document.getElementById("teacher-code").value,
        teacherEmail: document.getElementById("teacher-email").value,
        learnerName: document.getElementById("learner-name").value,
        grade: document.getElementById("grade").value,
        transgression: document.getElementById("transgression").value,
        comment: document.getElementById("comment").value,
        detentionDate: document.getElementById("detention-date").value,
    };

    const scriptURL = "https://script.google.com/macros/s/AKfycbybdidt1Y_XNKymQWt-fa7s3xr40Si3hlxLlNpO4ELLjhnQq6vfjNQcw9CHfY5GuGaG/exec"; // Replace with Apps Script Web App URL
    try {
        const response = await fetch(scriptURL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData),
        });

        if (response.ok) {
            alert("Detention issued successfully!");
        } else {
            throw new Error("Failed to submit data");
        }
    } catch (error) {
        console.error(error);
        alert("An error occurred while submitting the form.");
    }
});
